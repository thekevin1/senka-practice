<?php

namespace zkevinezzk\senka\practice\cmds;

use zkevinezzk\senka\practice\Loader;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TE;

class LobbyCommand extends Command {

    public function __construct() {
        parent::__construct("hub", "Teletransporta al jugador al lobby", "/hub", ["lobby", "spawn"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if ($sender instanceof Player) {

            Loader::getInstance()->getItemsProvider()->navigator($sender); 
            $sender->sendMessage(TE::GREEN . "You have teleported to the lobby!");
            
        } else {
            $sender->sendMessage(TE::RED . "This command can only be executed by a player.");
        }
        return true;
    }
}