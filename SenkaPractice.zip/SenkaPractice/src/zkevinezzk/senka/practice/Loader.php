<?php

namespace zkevinezzk\senka\practice;

use zkevinezzk\senka\practice\Handler;

use zkevinezzk\senka\practice\cmds\LobbyCommand;

use zkevinezzk\senka\practice\game\GameUtils;
use zkevinezzk\senka\practice\game\ItemsProvider;
use zkevinezzk\senka\practice\game\PlayerData;

use pocketmine\plugin\PluginBase;
use zkevinezzk\senka\practice\game\GameScoreboard;

class Loader extends PluginBase {
    
    /** @var Loader */
    private static $instance;

    public static function getInstance(): Loader {
        return self::$instance;
    }

    public static function getItemsProvider(): ItemsProvider {
        return new ItemsProvider();
    }    

    public static function getPlayerData(): PlayerData {
        return new PlayerData();
    }

    public static function getGameUtils(): GameUtils {
        return new GameUtils();
    }

    public static function getGameScoreboard(): GameScoreboard {
        return new GameScoreboard();
    }

    public function onEnable(): void {
        self::$instance = $this;

        $this->getServer()->getPluginManager()->registerEvents(new Handler(), $this);
        $this->getServer()->getCommandMap()->register("lobbycommand", new LobbyCommand());

        $this->getLogger()->info("Senka!");
    }

    public function onDisable(): void {
        self::$instance = null;
        $this->getLogger()->info("Senka!");
    }
}
