<?php

namespace zkevinezzk\senka\practice\game;

use zkevinezzk\senka\practice\Loader;

use pocketmine\player\Player;
use pocketmine\utils\Config;

class PlayerData {

    private $data;

    public function __construct() {
        $this->data = new Config(Loader::getInstance()->getDataFolder() . "player_data.yml", Config::YAML);
    }

    public function getPlayerData(Player $player): array {
        $uuid = $player->getUniqueId()->toString();
        if (!$this->data->exists($uuid)) {
            $this->data->set($uuid, ['kills' => 0, 'deaths' => 0, 'coins' => 0]);
            $this->data->save();
        }
        return $this->data->get($uuid);
    }

    public function savePlayerData(Player $player, array $data): void {
        $uuid = $player->getUniqueId()->toString();
        $this->data->set($uuid, $data);
        $this->data->save();
    }
    public function addKill(Player $player): void {
        $data = $this->getPlayerData($player);
        $data['kills'] += 1;
        $data['coins'] += 10;
        $this->savePlayerData($player, $data);
    }

    public function addDeath(Player $player): void {
        $data = $this->getPlayerData($player);
        $data['deaths'] += 1;
        $data['coins'] -= 5; 
        $this->savePlayerData($player, $data);
    }

    public function getKills(Player $player): int {
        $data = $this->getPlayerData($player);
        return $data['kills'];
    }

    public function getDeaths(Player $player): int {
        $data = $this->getPlayerData($player);
        return $data['deaths'];
    }

    public function getCoins(Player $player): int {
        $data = $this->getPlayerData($player);
        return $data['coins'];
    }
}
