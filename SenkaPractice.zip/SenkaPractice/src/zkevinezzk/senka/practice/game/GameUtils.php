<?php

namespace zkevinezzk\senka\practice\game;

use zkevinezzk\senka\practice\Loader;

use zkevinezzk\senka\practice\tasks\Scoreboard;
use zkevinezzk\senka\practice\tasks\Scoreboard2;
use zkevinezzk\senka\practice\tasks\Scoreboard3;
use zkevinezzk\senka\practice\tasks\Scoreboard4;

use pocketmine\item\PotionType;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class GameUtils {

    public function verifyWhereIsPlayer(Player $player): void {
        $worldName = $player->getWorld()->getWorldByName(); 

        switch ($worldName) {
            case "arena1":
            Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard2($player), 20);
                break;
            Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard3($player), 20);
            case "arena2":
                break;
            Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard4($player), 20);
            case "arena3":
                break;
            case "world":
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard($player), 20);
                break;

            default:
                $player->sendMessage("No estás en un mundo de arena reconocido.");
                break;
        }
    }

    public static function countHealingPotions(Player $player): int {
        $count = 0;
        $inventory = $player->getInventory();

        $pot = VanillaItems::SPLASH_POTION()->setType(PotionType::HEALING());

        foreach ($inventory->getContents() as $item) {
            if ($item->getTypeId() === $pot) {
                $count += $item->getCount(); 
            }
        }

        return $count;
    }

    public static function countGapples(Player $player): int {
        $count = 0;
        $inventory = $player->getInventory();

        foreach ($inventory->getContents() as $item) {
            if ($item->getTypeId() === VanillaItems::GOLDEN_APPLE) {
                $count += $item->getCount(); 
            }
        }

        return $count;
    }
}