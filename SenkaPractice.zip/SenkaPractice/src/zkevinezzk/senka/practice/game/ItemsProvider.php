<?php

namespace zkevinezzk\senka\practice\game;

use zkevinezzk\senka\practice\Loader;

use pocketmine\player\Player;
use pocketmine\player\GameMode;

use pocketmine\utils\TextFormat as TE;

use pocketmine\item\VanillaItems;

use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\EnchantmentInstance;

class ItemsProvider {

    public function clear(Player $player): void {
        $player->getInventory()->clearAll();
    }

    public function navigator(Player $player): void {

        $player->teleport(Loader::getInstance()->getServer()->getWorldManager()->getDefaultWorld()->getSpawnLocation());
        $n = VanillaItems::COMPASS()->setCustomName(TE::colorize("&bGames"));
        $n->setLore(["§c§c"]);

        $player->getInventory()->clearAll();
        $player->setGamemode(GameMode::ADVENTURE());
        $player->getInventory()->setItem(1, $n);

    }

    public function debuffKit(Player $player): void {
        $player->getInventory()->clearAll();
        $player->setGamemode(GameMode::ADVENTURE());
        $player->teleport(Loader::getInstance()->getServer()->getWorldManager()->getWorldByName("arena1")->getSpawnLocation());

        $sword = VanillaItems::DIAMOND_SWORD();
        $sword->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(9), 2));
        $sword->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 1));

        $pot = VanillaItems::SPLASH_POTION()->setType(PotionType::HEALING());
        $h = VanillaItems::DIAMOND_HELMET();
        $h->setCustomName(TE::colorize("&u&lSENKA"));
        $h->setLore(TE::colorize(["&u&lSENKA"]));
        $h->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $h->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $c = VanillaItems::DIAMOND_CHESTPLATE();
        $c->setCustomName(TE::colorize("&u&lSENKA"));
        $c->setLore(TE::colorize(["&u&lSENKA"]));
        $c->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $c->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $l = VanillaItems::DIAMOND_LEGGINGS();
        $l->setCustomName(TE::colorize("&u&lSENKA"));
        $l->setLore(TE::colorize(["&u&lSENKA"]));
        $l->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $l->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $b = VanillaItems::DIAMOND_BOOTS();
        $b->setCustomName(TE::colorize("&u&lSENKA"));
        $b->setLore(TE::colorize(["&u&lSENKA"]));
        $b->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $b->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $player->getArmorInventory()->setHelmet($h);
        $player->getArmorInventory()->setChestplate($c);
        $player->getArmorInventory()->setLeggings($l);
        $player->getArmorInventory()->setBoots($b);
        $player->getInventory()->addItem($sword);
        $player->getInventory()->addItem(VanillaItems::ENDER_PEARL()->setCount(16));
        $player->getInventory()->addItem(VanillaItems::STEAK()->setCount(16));

        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        $player->getInventory()->addItem($pot);
        // shitty code
    }

    public function gappleKit(Player $player): void {
        $player->getInventory()->clearAll();
        $player->setGamemode(GameMode::ADVENTURE());
        $player->teleport(Loader::getInstance()->getServer()->getWorldManager()->getWorldByName("arena2")->getSpawnLocation());

        $sword = VanillaItems::DIAMOND_SWORD();
        $sword->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(9), 2));
        $sword->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 1));

        $h = VanillaItems::DIAMOND_HELMET();
        $h->setCustomName(TE::colorize("&u&lSENKA"));
        $h->setLore(TE::colorize(["&u&lSENKA"]));
        $h->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $h->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $c = VanillaItems::DIAMOND_CHESTPLATE();
        $c->setCustomName(TE::colorize("&u&lSENKA"));
        $c->setLore(TE::colorize(["&u&lSENKA"]));
        $c->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $c->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $l = VanillaItems::DIAMOND_LEGGINGS();
        $l->setCustomName(TE::colorize("&u&lSENKA"));
        $l->setLore(TE::colorize(["&u&lSENKA"]));
        $l->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $l->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $b = VanillaItems::DIAMOND_BOOTS();
        $b->setCustomName(TE::colorize("&u&lSENKA"));
        $b->setLore(TE::colorize(["&u&lSENKA"]));
        $b->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(0), 2));
        $b->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17), 2));

        $player->getArmorInventory()->setHelmet($h);
        $player->getArmorInventory()->setChestplate($c);
        $player->getArmorInventory()->setLeggings($l);
        $player->getArmorInventory()->setBoots($b);
        $player->getInventory()->addItem($sword);
        $player->getInventory()->addItem(VanillaItems::ENDER_PEARL()->setCount(16));
        $player->getInventory()->addItem(VanillaItems::GOLDEN_APPLE()->setCount(32));
    }

    public function resistanceKit(Player $player): void {
        $player->getInventory()->clearAll();
        $player->setGamemode(GameMode::ADVENTURE());
        $player->teleport(Loader::getInstance()->getServer()->getWorldManager()->getWorldByName("arena3")->getSpawnLocation());

        $player->getInventory()->addItem(VanillaItems::WOODEN_SWORD()->setCount(1));
    }
}