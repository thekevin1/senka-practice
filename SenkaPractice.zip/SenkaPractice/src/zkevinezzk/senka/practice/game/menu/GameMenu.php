<?php

namespace zkevinezzk\senka\practice\game\menu;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use jojoe77777\FormAPI\SimpleForm;

use zkevinezzk\senka\practice\Loader;

class GameMenu {

    public static function openUi(Player $player): void {
        $name = $player->getName();
        $coins = Loader::getInstance()->getPlayerData()->getCoins($player);
        $kills = Loader::getInstance()->getPlayerData()->getKills($player);
        $deaths = Loader::getInstance()->getPlayerData()->getDeaths($player);

        // Crear el formulario
        $form = new SimpleForm(function(Player $player, int $data = null): void {
            if ($data === null) return; 

            switch ($data) {
                case 0:
                    Loader::getInstance()->getItemsProvider()->debuffKit($player);
                    break;
                case 1:
                    Loader::getInstance()->getItemsProvider()->gappleKit($player);
                    break;
                case 2:
                    Loader::getInstance()->getItemsProvider()->resistanceKit($player);
                    break;
                default:
                    break;
            }
        });

        $form->setTitle(TextFormat::GOLD . "Tus Estadísticas");
        $form->setContent("Coins: $coins\nKills: $kills\nDeaths: $deaths");

        // Añadir botones con imágenes
        $form->addButton(TextFormat::RED . "Debuff", 0, "textures/items/potion_bottle_heal.png");
        $form->addButton(TextFormat::GOLD . "Gapple", 1, "textures/items/apple_golden.png");
        $form->addButton(TextFormat::GRAY . "Resistance", 2, "textures/ui/resistance_effect.png");

        $player->sendForm($form);
    }
}