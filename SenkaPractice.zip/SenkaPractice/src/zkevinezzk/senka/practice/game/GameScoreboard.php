<?php 

namespace zkevinezzk\senka\practice\game;


use zkevinezzk\senka\practice\Loader;
use zkevinezzk\senka\practice\game\api\ScoreboardApi as sc;

use pocketmine\utils\TextFormat as TE;

use pocketmine\player\Player;

class GameScoreboard {

    public function lobbyScoreboard(Player $player): void {
        if ($player->isOnline()) {

            $name = $player->getName();
            $coins = Loader::getInstance()->getPlayerData()->getCoins($player);
            $ping = $player->getNetworkSession()->getPing();

            sc::removeScore($player); 
            sc::setScore($player, TE::colorize("&uSENKA"));
            sc::setScoreLine($player, 1, TE::colorize("&u&l&0"));
            sc::setScoreLine($player, 2, TE::colorize("&u&l" . $name . "&r"));
            sc::setScoreLine($player, 3, TE::colorize("&u&lCoins:&r&f " . $coins . "&r"));
            sc::setScoreLine($player, 4, TE::colorize("&u&lPing:&r&f " . $ping . "&r"));
            sc::setScoreLine($player, 5, TE::colorize("&u&l&k"));
            sc::setScoreLine($player, 6, TE::colorize("&7senka.ddns.net"));
        }
    }

    public function debuffScoreboard(Player $player): void {
        if ($player->isOnline()) {

            $name = $player->getName();
            $kills = Loader::getInstance()->getPlayerData()->getKills($player);
            $deaths = Loader::getInstance()->getPlayerData()->getDeaths($player);
            $pots = Loader::getInstance()->getGameUtils()->countHealingPotions($player);
            $ping = $player->getNetworkSession()->getPing();

            sc::removeScore($player); 
            sc::setScore($player, TE::colorize("&uSENKA"));
            sc::setScoreLine($player, 1, TE::colorize("&u&l&0"));
            sc::setScoreLine($player, 2, TE::colorize("&u&l" . $name . "&r"));
            sc::setScoreLine($player, 3, TE::colorize("&u&lKills:&r&f " . $kills . "&r"));
            sc::setScoreLine($player, 4, TE::colorize("&u&lDeaths:&r&f " . $deaths . "&r"));
            sc::setScoreLine($player, 5, TE::colorize("&u&0&k"));
            sc::setScoreLine($player, 6, TE::colorize("&u&lPots:&r&f" . $pots . "&r"));
            sc::setScoreLine($player, 7, TE::colorize("&u&l&k&r&r"));
            sc::setScoreLine($player, 8, TE::colorize("&u&lPing:&r&f " . $ping . "&r"));
            sc::setScoreLine($player, 9, TE::colorize("&u&l&k"));
            sc::setScoreLine($player, 10, TE::colorize("&7senka.ddns.net"));
        }
    }

    public function gappleScoreboard(Player $player): void {
        if ($player->isOnline()) {

            $name = $player->getName();
            $kills = Loader::getInstance()->getPlayerData()->getKills($player);
            $deaths = Loader::getInstance()->getPlayerData()->getDeaths($player);
            $gaps = Loader::getInstance()->getGameUtils()->countGapples($player);
            $ping = $player->getNetworkSession()->getPing();

            sc::removeScore($player); 
            sc::setScore($player, TE::colorize("&uSENKA"));
            sc::setScoreLine($player, 1, TE::colorize("&u&l&0"));
            sc::setScoreLine($player, 2, TE::colorize("&u&l" . $name . "&r"));
            sc::setScoreLine($player, 3, TE::colorize("&u&lKills:&r&f " . $kills . "&r"));
            sc::setScoreLine($player, 4, TE::colorize("&u&lDeaths:&r&f " . $deaths . "&r"));
            sc::setScoreLine($player, 5, TE::colorize("&u&0&k"));
            sc::setScoreLine($player, 6, TE::colorize("&u&lGaps:&r&f" . $gaps . "&r"));
            sc::setScoreLine($player, 7, TE::colorize("&u&l&k&r&r"));
            sc::setScoreLine($player, 8, TE::colorize("&u&lPing:&r&f " . $ping . "&r"));
            sc::setScoreLine($player, 9, TE::colorize("&u&l&k"));
            sc::setScoreLine($player, 10, TE::colorize("&7senka.ddns.net"));
        }
    }

    public function resistanceScoreboard(Player $player): void {
        if ($player->isOnline()) {

            $name = $player->getName();
            $kills = Loader::getInstance()->getPlayerData()->getKills($player);
            $deaths = Loader::getInstance()->getPlayerData()->getDeaths($player);
            $ping = $player->getNetworkSession()->getPing();

            sc::removeScore($player); 
            sc::setScore($player, TE::colorize("&uSENKA"));
            sc::setScoreLine($player, 1, TE::colorize("&u&l&0"));
            sc::setScoreLine($player, 2, TE::colorize("&u&l" . $name . "&r"));
            sc::setScoreLine($player, 3, TE::colorize("&u&lKills:&r&f " . $kills . "&r"));
            sc::setScoreLine($player, 4, TE::colorize("&u&lDeaths:&r&f " . $deaths . "&r"));
            sc::setScoreLine($player, 5, TE::colorize("&u&l&k&r&r"));
            sc::setScoreLine($player, 6, TE::colorize("&u&lPing:&r&f " . $ping . "&r"));
            sc::setScoreLine($player, 7, TE::colorize("&u&l&k"));
            sc::setScoreLine($player, 8, TE::colorize("&7senka.ddns.net"));
        }
    }
}