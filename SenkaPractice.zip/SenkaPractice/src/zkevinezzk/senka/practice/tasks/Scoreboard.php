<?php

namespace zkevinezzk\senka\practice\tasks;

use zkevinezzk\senka\practice\Loader;

use pocketmine\scheduler\Task;
use pocketmine\player\Player;

class Scoreboard extends Task {
    private $player;
    
    public function __construct(Player $player) {
        $this->player = $player;
    }

    public function onRun(): void {
        Loader::getInstance()->getGameScoreboard()->lobbyScoreboard($this->player);
    }
}
