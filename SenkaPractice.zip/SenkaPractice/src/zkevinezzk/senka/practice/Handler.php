<?php

namespace zkevinezzk\senka\practice;

use zkevinezzk\senka\practice\Loader;
use zkevinezzk\senka\practice\game\menu\GameMenu;

use pocketmine\player\Player;

use pocketmine\event\player\PlayerInteractEvent;	
use pocketmine\scheduler\ClosureTask;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;

use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerRespawnEvent;

use pocketmine\event\entity\EntityDamageByEntityEvent;

class Handler implements Listener {

    public function onEnter(PlayerJoinEvent $event): void {

        $player = $event->getPlayer();

        $task = new ClosureTask(function() use ($player): void {
            Loader::getInstance()->getGameUtils()->verifyWhereIsPlayer($player);
        });

        Loader::getInstance()->getScheduler()->scheduleRepeatingTask($task, 100); 

        Loader::getInstance()->getItemsProvider()->navigator($player);

        $event->setJoinMessage(TE::colorize("&a[+] " . $player->getName()));
    }

    public function onLeave(PlayerQuitEvent $event): void {

        $player = $event->getPlayer();

        Loader::getInstance()->getItemsProvider()->clear($player); 

        $event->setJoinMessage(TE::colorize("&c[-] " . $player->getName()));

    }

    public function onDie(PlayerDeathEvent $event): void {

        $player = $event->getPlayer();

        Loader::getInstance()->getPlayerData()->addDeath($player);

        $player->sendPopup(TE::colorize("&cYou lose 5 coins."));
    }
    
    public function onRespawn(PlayerRespawnEvent $event): void {

        $player = $event->getPlayer();

        Loader::getInstance()->getItemsProvider()->navigator($player);  
    }
    
    public function onKill(EntityDamageByEntityEvent $event): void {

        $player = $event->getDamager();
        $victim = $event->getEntity();

        if ($event->getEntity() instanceof Player && $event->getDamager() instanceof Player) {

            Loader::getInstance()->getPlayerData()->addKill($player);
            $player->sendPopup(TE::colorize("&aYou won 10 coins."));
            Loader::getInstance()->getServer()->broadcastMessage("§7" . $player->getName() . " ha matado a " . $victim->getName() . ".");
        }
    }

    public function itemUse(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand(); 
        
        if ($item->getLore() === "§c§c") {
            GameMenu::openUi($player);
        }
    }    
}